﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace EasyMobile.Demo
{
    public class ScrollableListItem : MonoBehaviour
    {
        public Text title;
        public Text subtitle;
        public Button button;
    }
}
